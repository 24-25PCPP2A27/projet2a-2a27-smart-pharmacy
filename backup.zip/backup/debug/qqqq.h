#ifndef QQQQ_H
#define QQQQ_H


class qqqq
{
public:
    qqqq();
};

#endif // QQQQ_H
