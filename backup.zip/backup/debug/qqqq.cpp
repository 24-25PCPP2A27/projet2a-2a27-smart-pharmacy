#include "qqqq.h"

qqqq::qqqq()
{

}
