/********************************************************************************
** Form generated from reading UI file 'gestion_employes.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESTION_EMPLOYES_H
#define UI_GESTION_EMPLOYES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Gestion_employes
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Gestion_employes)
    {
        if (Gestion_employes->objectName().isEmpty())
            Gestion_employes->setObjectName(QStringLiteral("Gestion_employes"));
        Gestion_employes->resize(800, 600);
        centralwidget = new QWidget(Gestion_employes);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Gestion_employes->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Gestion_employes);
        menubar->setObjectName(QStringLiteral("menubar"));
        Gestion_employes->setMenuBar(menubar);
        statusbar = new QStatusBar(Gestion_employes);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Gestion_employes->setStatusBar(statusbar);

        retranslateUi(Gestion_employes);

        QMetaObject::connectSlotsByName(Gestion_employes);
    } // setupUi

    void retranslateUi(QMainWindow *Gestion_employes)
    {
        Gestion_employes->setWindowTitle(QApplication::translate("Gestion_employes", "Gestion_employes", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Gestion_employes: public Ui_Gestion_employes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESTION_EMPLOYES_H
