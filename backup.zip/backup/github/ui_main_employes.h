/********************************************************************************
** Form generated from reading UI file 'main_employes.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_EMPLOYES_H
#define UI_MAIN_EMPLOYES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionExit;
    QAction *actionGen_rer_PDF;
    QAction *actionStatistiques;
    QWidget *centralWidget;
    QTabWidget *tabSponsor;
    QWidget *tab;
    QGroupBox *groupBox_3;
    QTableView *tab_employes;
    QGroupBox *groupBox;
    QLabel *label_ID;
    QLabel *label_Nom;
    QLabel *label_Adr;
    QLineEdit *lineEdit_nomE;
    QLineEdit *lineEdit_PrenomE;
    QPushButton *pb_ajouter;
    QLabel *label_Adr_2;
    QLineEdit *lineEdit_mail;
    QPushButton *pb_modifier;
    QPushButton *pushButton_2;
    QLabel *label_img_2;
    QLineEdit *lineEdit_salaire;
    QLabel *label_Adr_3;
    QLabel *label_Adr_4;
    QLabel *label_Adr_5;
    QLineEdit *lineEdit_poste;
    QLineEdit *lineEdit_HDT;
    QLineEdit *lineEdit_ID;
    QLineEdit *lineEdit_id_sup;
    QPushButton *pb_supp;
    QLabel *label;
    QLabel *label_recherche;
    QLineEdit *lineEdit_recherche;
    QPushButton *pb_recherche;
    QLabel *countdown;
    QPushButton *pb_trier;
    QPushButton *pb_pdf;
    QPushButton *pb_showStatsButton;
    QPushButton *pb_qr;
    QMenuBar *menuBar;
    QMenu *menuSponsor;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1208, 682);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon;
        icon.addFile(QStringLiteral("../../design/new icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QStringLiteral("actionExit"));
        QIcon icon1;
        icon1.addFile(QStringLiteral("../../design/close-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon1);
        actionGen_rer_PDF = new QAction(MainWindow);
        actionGen_rer_PDF->setObjectName(QStringLiteral("actionGen_rer_PDF"));
        QIcon icon2;
        icon2.addFile(QStringLiteral("../../design/pdf_icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionGen_rer_PDF->setIcon(icon2);
        actionStatistiques = new QAction(MainWindow);
        actionStatistiques->setObjectName(QStringLiteral("actionStatistiques"));
        QIcon icon3;
        icon3.addFile(QStringLiteral("../../design/stats.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStatistiques->setIcon(icon3);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabSponsor = new QTabWidget(centralWidget);
        tabSponsor->setObjectName(QStringLiteral("tabSponsor"));
        tabSponsor->setGeometry(QRect(-10, 30, 1231, 611));
        tabSponsor->setStyleSheet(QStringLiteral(""));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(30, 10, 1151, 571));
        groupBox_3->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 238);\n"
"background-color: rgb(233, 255, 254);"));
        tab_employes = new QTableView(groupBox_3);
        tab_employes->setObjectName(QStringLiteral("tab_employes"));
        tab_employes->setGeometry(QRect(480, 240, 501, 261));
        tab_employes->setStyleSheet(QStringLiteral(""));
        groupBox = new QGroupBox(groupBox_3);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 30, 461, 491));
        groupBox->setStyleSheet(QStringLiteral(""));
        label_ID = new QLabel(groupBox);
        label_ID->setObjectName(QStringLiteral("label_ID"));
        label_ID->setGeometry(QRect(10, 40, 141, 16));
        QFont font;
        font.setFamily(QStringLiteral("OCR A Extended"));
        font.setPointSize(10);
        label_ID->setFont(font);
        label_Nom = new QLabel(groupBox);
        label_Nom->setObjectName(QStringLiteral("label_Nom"));
        label_Nom->setGeometry(QRect(10, 80, 161, 16));
        label_Nom->setFont(font);
        label_Adr = new QLabel(groupBox);
        label_Adr->setObjectName(QStringLiteral("label_Adr"));
        label_Adr->setGeometry(QRect(10, 120, 151, 16));
        label_Adr->setFont(font);
        lineEdit_nomE = new QLineEdit(groupBox);
        lineEdit_nomE->setObjectName(QStringLiteral("lineEdit_nomE"));
        lineEdit_nomE->setGeometry(QRect(200, 39, 181, 21));
        lineEdit_nomE->setStyleSheet(QLatin1String("border-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        lineEdit_PrenomE = new QLineEdit(groupBox);
        lineEdit_PrenomE->setObjectName(QStringLiteral("lineEdit_PrenomE"));
        lineEdit_PrenomE->setGeometry(QRect(200, 79, 181, 21));
        lineEdit_PrenomE->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 207);\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        lineEdit_PrenomE->setInputMethodHints(Qt::ImhNone);
        pb_ajouter = new QPushButton(groupBox);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(250, 400, 161, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("OCR A Extended"));
        font1.setPointSize(16);
        pb_ajouter->setFont(font1);
        pb_ajouter->setAutoFillBackground(false);
        pb_ajouter->setStyleSheet(QLatin1String("\n"
"color: rgb(35, 170, 102);\n"
""));
        label_Adr_2 = new QLabel(groupBox);
        label_Adr_2->setObjectName(QStringLiteral("label_Adr_2"));
        label_Adr_2->setGeometry(QRect(10, 160, 151, 16));
        label_Adr_2->setFont(font);
        lineEdit_mail = new QLineEdit(groupBox);
        lineEdit_mail->setObjectName(QStringLiteral("lineEdit_mail"));
        lineEdit_mail->setGeometry(QRect(200, 159, 181, 21));
        lineEdit_mail->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        pb_modifier = new QPushButton(groupBox);
        pb_modifier->setObjectName(QStringLiteral("pb_modifier"));
        pb_modifier->setGeometry(QRect(30, 400, 161, 41));
        pb_modifier->setFont(font1);
        pb_modifier->setAutoFillBackground(false);
        pb_modifier->setStyleSheet(QLatin1String("\n"
"color: rgb(35, 170, 102);\n"
""));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(520, 210, 181, 31));
        label_img_2 = new QLabel(groupBox);
        label_img_2->setObjectName(QStringLiteral("label_img_2"));
        label_img_2->setGeometry(QRect(540, 250, 161, 161));
        label_img_2->setStyleSheet(QStringLiteral("capacity:10%;"));
        lineEdit_salaire = new QLineEdit(groupBox);
        lineEdit_salaire->setObjectName(QStringLiteral("lineEdit_salaire"));
        lineEdit_salaire->setGeometry(QRect(200, 200, 181, 21));
        lineEdit_salaire->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        label_Adr_3 = new QLabel(groupBox);
        label_Adr_3->setObjectName(QStringLiteral("label_Adr_3"));
        label_Adr_3->setGeometry(QRect(10, 200, 151, 16));
        label_Adr_3->setFont(font);
        label_Adr_4 = new QLabel(groupBox);
        label_Adr_4->setObjectName(QStringLiteral("label_Adr_4"));
        label_Adr_4->setGeometry(QRect(10, 290, 151, 16));
        label_Adr_4->setFont(font);
        label_Adr_5 = new QLabel(groupBox);
        label_Adr_5->setObjectName(QStringLiteral("label_Adr_5"));
        label_Adr_5->setGeometry(QRect(10, 250, 151, 16));
        label_Adr_5->setFont(font);
        lineEdit_poste = new QLineEdit(groupBox);
        lineEdit_poste->setObjectName(QStringLiteral("lineEdit_poste"));
        lineEdit_poste->setGeometry(QRect(200, 250, 181, 21));
        lineEdit_poste->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        lineEdit_HDT = new QLineEdit(groupBox);
        lineEdit_HDT->setObjectName(QStringLiteral("lineEdit_HDT"));
        lineEdit_HDT->setGeometry(QRect(200, 290, 181, 21));
        lineEdit_HDT->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        lineEdit_ID = new QLineEdit(groupBox);
        lineEdit_ID->setObjectName(QStringLiteral("lineEdit_ID"));
        lineEdit_ID->setGeometry(QRect(200, 120, 181, 21));
        lineEdit_ID->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 207);\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        lineEdit_ID->setInputMethodHints(Qt::ImhNone);
        lineEdit_id_sup = new QLineEdit(groupBox_3);
        lineEdit_id_sup->setObjectName(QStringLiteral("lineEdit_id_sup"));
        lineEdit_id_sup->setGeometry(QRect(530, 520, 181, 21));
        lineEdit_id_sup->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        pb_supp = new QPushButton(groupBox_3);
        pb_supp->setObjectName(QStringLiteral("pb_supp"));
        pb_supp->setGeometry(QRect(720, 510, 131, 41));
        QFont font2;
        font2.setFamily(QStringLiteral("OCR A Extended"));
        font2.setPointSize(12);
        pb_supp->setFont(font2);
        pb_supp->setStyleSheet(QStringLiteral("color: rgb(35, 170, 102);"));
        label = new QLabel(groupBox_3);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(480, 520, 41, 20));
        QFont font3;
        font3.setPointSize(9);
        label->setFont(font3);
        label_recherche = new QLabel(groupBox_3);
        label_recherche->setObjectName(QStringLiteral("label_recherche"));
        label_recherche->setGeometry(QRect(540, 220, 131, 16));
        QFont font4;
        font4.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font4.setPointSize(10);
        label_recherche->setFont(font4);
        lineEdit_recherche = new QLineEdit(groupBox_3);
        lineEdit_recherche->setObjectName(QStringLiteral("lineEdit_recherche"));
        lineEdit_recherche->setGeometry(QRect(640, 220, 181, 21));
        lineEdit_recherche->setStyleSheet(QLatin1String("border-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        pb_recherche = new QPushButton(groupBox_3);
        pb_recherche->setObjectName(QStringLiteral("pb_recherche"));
        pb_recherche->setGeometry(QRect(850, 200, 131, 41));
        pb_recherche->setFont(font2);
        pb_recherche->setStyleSheet(QLatin1String("color: rgb(216, 191, 0);\n"
"color: rgb(35, 170, 102);"));
        countdown = new QLabel(groupBox_3);
        countdown->setObjectName(QStringLiteral("countdown"));
        countdown->setGeometry(QRect(980, 10, 131, 51));
        pb_trier = new QPushButton(groupBox_3);
        pb_trier->setObjectName(QStringLiteral("pb_trier"));
        pb_trier->setGeometry(QRect(980, 360, 161, 41));
        pb_trier->setFont(font1);
        pb_trier->setAutoFillBackground(false);
        pb_trier->setStyleSheet(QLatin1String("\n"
"color: rgb(35, 170, 102);\n"
""));
        pb_pdf = new QPushButton(groupBox_3);
        pb_pdf->setObjectName(QStringLiteral("pb_pdf"));
        pb_pdf->setGeometry(QRect(1010, 180, 131, 41));
        pb_pdf->setFont(font2);
        pb_pdf->setStyleSheet(QLatin1String("color: rgb(216, 191, 0);\n"
"color: rgb(35, 170, 102);"));
        pb_showStatsButton = new QPushButton(groupBox_3);
        pb_showStatsButton->setObjectName(QStringLiteral("pb_showStatsButton"));
        pb_showStatsButton->setGeometry(QRect(930, 510, 201, 41));
        pb_showStatsButton->setFont(font1);
        pb_showStatsButton->setAutoFillBackground(false);
        pb_showStatsButton->setStyleSheet(QLatin1String("\n"
"color: rgb(35, 170, 102);\n"
""));
        pb_qr = new QPushButton(groupBox_3);
        pb_qr->setObjectName(QStringLiteral("pb_qr"));
        pb_qr->setGeometry(QRect(590, 90, 93, 28));
        tabSponsor->addTab(tab, QString());
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1208, 26));
        menuSponsor = new QMenu(menuBar);
        menuSponsor->setObjectName(QStringLiteral("menuSponsor"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuSponsor->menuAction());
        menuSponsor->addSeparator();
        menuSponsor->addAction(actionNew);
        menuSponsor->addAction(actionGen_rer_PDF);
        menuSponsor->addAction(actionStatistiques);
        menuSponsor->addAction(actionExit);

        retranslateUi(MainWindow);

        tabSponsor->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Gestion des Sponsors", Q_NULLPTR));
        actionNew->setText(QApplication::translate("MainWindow", "New", Q_NULLPTR));
        actionExit->setText(QApplication::translate("MainWindow", "Exit", Q_NULLPTR));
        actionGen_rer_PDF->setText(QApplication::translate("MainWindow", "Gen\303\251rer PDF", Q_NULLPTR));
        actionStatistiques->setText(QApplication::translate("MainWindow", "Statistiques", Q_NULLPTR));
        groupBox_3->setTitle(QString());
        groupBox->setTitle(QString());
        label_ID->setText(QApplication::translate("MainWindow", "Nom employes:", Q_NULLPTR));
        label_Nom->setText(QApplication::translate("MainWindow", "prenom employes:", Q_NULLPTR));
        label_Adr->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        pb_ajouter->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        label_Adr_2->setText(QApplication::translate("MainWindow", "Mail :", Q_NULLPTR));
        pb_modifier->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "S\303\251l\303\251ctionnez une image", Q_NULLPTR));
        label_img_2->setText(QString());
        label_Adr_3->setText(QApplication::translate("MainWindow", "Salaire :", Q_NULLPTR));
        label_Adr_4->setText(QApplication::translate("MainWindow", "Heure de travail : ", Q_NULLPTR));
        label_Adr_5->setText(QApplication::translate("MainWindow", "Poste :", Q_NULLPTR));
        lineEdit_id_sup->setText(QString());
        pb_supp->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_recherche->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        pb_recherche->setText(QApplication::translate("MainWindow", "Recherche", Q_NULLPTR));
        countdown->setText(QApplication::translate("MainWindow", "TextLabel", Q_NULLPTR));
        pb_trier->setText(QApplication::translate("MainWindow", "TRIER", Q_NULLPTR));
        pb_pdf->setText(QApplication::translate("MainWindow", "PDF", Q_NULLPTR));
        pb_showStatsButton->setText(QApplication::translate("MainWindow", "statistique", Q_NULLPTR));
        pb_qr->setText(QApplication::translate("MainWindow", "QR", Q_NULLPTR));
        tabSponsor->setTabText(tabSponsor->indexOf(tab), QApplication::translate("MainWindow", "Fournisseur", Q_NULLPTR));
        menuSponsor->setTitle(QApplication::translate("MainWindow", "foursn", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_EMPLOYES_H
